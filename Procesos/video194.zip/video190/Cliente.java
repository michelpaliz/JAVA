

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


public class Cliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MarcoCliente mimarco=new MarcoCliente();
		
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}


class MarcoCliente extends JFrame{
	
	public MarcoCliente(){
		
		setBounds(600,300,280,350);
				
		LaminaMarcoCliente milamina=new LaminaMarcoCliente();
		
		add(milamina);
		
		setVisible(true);
		}	
	
}

class LaminaMarcoCliente extends JPanel implements Runnable{
	
	public LaminaMarcoCliente(){

		nick = new JTextField(5);

		add(nick);

		JLabel texto=new JLabel("CHAT");
		
		add(texto);

		ip = new JTextField(8);

		add(ip);

		campoChat = new JTextArea(12,20);

		add(campoChat);

		campo1=new JTextField(20);
	
		add(campo1);		
	
		miboton=new JButton("Enviar");

		//Creamos la instacia del texto
		EnviaTexto enviaTexto = new EnviaTexto();
		miboton.addActionListener(enviaTexto);
		
		add(miboton);

		Thread thread = new Thread(this);

		thread.start();
		
	}

	@Override
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(9090);
			PaqueteEnvio paqueteEnvio;
			Socket socket;
			while (true){
				socket = serverSocket.accept();
				ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
				paqueteEnvio = (PaqueteEnvio) objectInputStream.readObject();
				campoChat.append("\n" + paqueteEnvio.getNick() + ": " + paqueteEnvio.getMensaje());
			}

		}catch (Exception e){

		}

	}

	//Creamos el listener
	
	private class EnviaTexto implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println(campo1.getText());

			try {
				Socket socket = new Socket("192.168.9.127",9999);

				PaqueteEnvio paqueteEnvio = new PaqueteEnvio();

				paqueteEnvio.setNick(nick.getText());

				paqueteEnvio.setIp(ip.getText());

				paqueteEnvio.setMensaje(campo1.getText());

				ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());

				objectOutputStream.writeObject(paqueteEnvio);

				socket.close();

//				DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
//				dataOutputStream.writeUTF(campo1.getText());
//				dataOutputStream.close();
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
		}
	}
		
	private JTextField campo1, nick, ip;

	private JTextArea campoChat;
	
	private JButton miboton;
	
}

class PaqueteEnvio implements Serializable {

	private String nick,ip, mensaje;

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}